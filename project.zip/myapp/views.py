import imp
from django.http import HttpResponse
from django.shortcuts import render
from .models import Data
from .forms import Form
def index(request):
    return render(request,"index.html")

def upload(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        hobby = request.POST['hobby']
        form = Form(request.POST or None)
        if(form.is_valid()):
            form.save()
    return render(request,"result.html",{"name":name,"email":email,"hobby":hobby})